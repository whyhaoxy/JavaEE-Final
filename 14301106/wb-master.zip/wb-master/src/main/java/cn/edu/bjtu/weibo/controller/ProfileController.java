package cn.edu.bjtu.weibo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ProfileController {

	@RequestMapping(value="",method=RequestMethod.GET)
	public String getName(){
		return  "";
	}
//	public String asdf(HttpServletRequest request,HttpServletResponse response){
//		
//		return "home";
//	}
	
}
